clear; close all;
dbstop if error

%% ================= 1. 数据集与路径配置 =================
dataset = 2; 
base_dir      = 'D:\datasets\kitti_2015\training';
folder_left   = fullfile(base_dir, 'image_2'); 
folder_right  = fullfile(base_dir, 'image_3'); 

% 分别设置 NOC(非遮挡) 和 ALL(包含遮挡) 的真值路径
folder_GT_noc = fullfile(base_dir, 'disp_noc_0'); 
folder_GT_all = fullfile(base_dir, 'disp_occ_0'); 

folder_result = 'D:\datasets\kitti_2015\training\baseline_results\';
if ~exist(folder_result, 'dir'), mkdir(folder_result); end
files_left  = dir(fullfile(folder_left, '*.png'));

%% ================= 2. 初始化统计与TXT文件 =================
% 打开txt文件准备写入
txt_filepath = fullfile(folder_result, 'evaluation_results.txt');
fid = fopen(txt_filepath, 'w');
fprintf(fid, 'Image_Name\tBad3.0_NOC(%%)\tBad3.0_ALL(%%)\n');

% 初始化全局统计变量（用于计算平均误差）
total_bad_noc = 0; total_valid_noc = 0;
total_bad_all = 0; total_valid_all = 0;

% 默认处理设置
start_idx = 0 * dataset; 
end_idx   = 199 * dataset;  

%% ================= 3. 主循环处理 =================
for i_idx = start_idx: end_idx
    tic; 
    
    %% 3.1 图像读取
    file_info_L = files_left(i_idx+1);
    name_L = file_info_L.name;
    
    path_L      = fullfile(folder_left, name_L);
    path_R      = fullfile(folder_right, name_L); 
    path_GT_noc = fullfile(folder_GT_noc, name_L);
    path_GT_all = fullfile(folder_GT_all, name_L);
    
    if ~exist(path_GT_noc, 'file'), continue; end
    
    img_L = imread(path_L);
    img_R = imread(path_R);
    img_GT_noc = double(imread(path_GT_noc)); 
    % 如果有disp_occ_0则读取ALL真值，否则暂且用NOC替代避免报错
    if exist(path_GT_all, 'file')
        img_GT_all = double(imread(path_GT_all)); 
    else
        img_GT_all = img_GT_noc; 
    end
    
    if size(img_L, 3) == 3
        imgL_gray = uint8(rgb2gray(img_L)); 
        imgR_gray = uint8(rgb2gray(img_R));
    else
        imgL_gray = img_L;
        imgR_gray = img_R;
    end
    [H, W] = size(imgL_gray);
    
    %% 3.2 参数设置
    Dmax       = 127; 
    census_win = 9; 
    box_win    = 9; 
    box_radius = (box_win - 1) / 2;
    
    %% 3.3 初始代价计算 (Census)
    [cost_vol_L, ~] = census_hanming(imgL_gray, imgR_gray, census_win, Dmax);
    
    %% 3.4 代价聚合 (Standard Box Filter)
    cost_aggr_L = zeros(H, W, Dmax+1);
    for d = 1:Dmax+1
        cost_aggr_L(:,:,d) = imboxfilt(double(cost_vol_L(:,:,d)), box_win);
    end
    
    %% 3.5 生成右图代价卷
    cost_aggr_R = Inf(H, W, Dmax+1);
    for d = 1 : Dmax+1
        disp_val = d - 1;
        if W > disp_val
            cost_aggr_R(:, 1 : W-disp_val, d) = cost_aggr_L(:, 1+disp_val : W, d);
        end
    end
    
    %% 3.6 视差计算 (Standard WTA)
    [~, idx_L] = min(cost_aggr_L, [], 3);
    disp_L_initial = double(idx_L - 1);
    
    [~, idx_R] = min(cost_aggr_R, [], 3);
    disp_R_initial = double(idx_R - 1);
    
    %% 3.7 左右一致性检查 (LRC)
    [disp_L_lrc, ~] = check_lr(disp_L_initial, disp_R_initial, 1);
    
    %% 3.8 后处理：基础填充与平滑
    hole_mask = (disp_L_lrc <= 0); 
    disp_L_filled = fillHolesLRC(disp_L_lrc, hole_mask);
    
    disp_L_final = medfilt2(disp_L_filled, [3, 3]);
    disp_L_final = medfilt2(disp_L_final, [3, 3]);
    
    %% 3.9 精度评估与统计 (NOC & ALL)
    % 评估 NOC 区域
    GT_val_noc = img_GT_noc / 256.0;
    valid_mask_noc = (GT_val_noc > 0);
    err_map_noc = abs(double(disp_L_final) - GT_val_noc);
    bad_pixels_noc = (err_map_noc > 3.0) & valid_mask_noc;
    
    % 评估 ALL 区域
    GT_val_all = img_GT_all / 256.0;
    valid_mask_all = (GT_val_all > 0);
    err_map_all = abs(double(disp_L_final) - GT_val_all);
    bad_pixels_all = (err_map_all > 3.0) & valid_mask_all;
    
    % 当前图片的误差率
    bad3_pct_noc = sum(bad_pixels_noc(:)) / sum(valid_mask_noc(:)) * 100;
    bad3_pct_all = sum(bad_pixels_all(:)) / sum(valid_mask_all(:)) * 100;
    
    % 累加全局统计变量
    total_bad_noc = total_bad_noc + sum(bad_pixels_noc(:));
    total_valid_noc = total_valid_noc + sum(valid_mask_noc(:));
    total_bad_all = total_bad_all + sum(bad_pixels_all(:));
    total_valid_all = total_valid_all + sum(valid_mask_all(:));
    
    % 控制台输出与 TXT 写入
    fprintf('Processed: %s | Bad3.0 NOC: %.2f%% | ALL: %.2f%%\n', name_L, bad3_pct_noc, bad3_pct_all);
    fprintf(fid, '%s\t%.4f\t%.4f\n', name_L, bad3_pct_noc, bad3_pct_all);
    
    %% 3.10 保存结果
    base_name = strrep(name_L, '.png', '');
    
    % 保存视差图
    disp_norm = disp_L_final / Dmax;
    disp_norm(disp_norm > 1) = 1; 
    disp_rgb = ind2rgb(uint8(disp_norm * 255), turbo(256));
    imwrite(disp_rgb, fullfile(folder_result, [base_name, '_disp_baseline.png']));
    
    % 保存误差图 (以NOC真值为基准保存误差图)
    err_img = zeros(H, W, 3);
    is_correct = (err_map_noc <= 3.0) & valid_mask_noc;
    err_img(repmat(is_correct, [1, 1, 3])) = 1; % 正确区域为白色
    is_over = bad_pixels_noc; % 误差区域
    tmp_R = err_img(:,:,1); tmp_R(is_over) = 1; err_img(:,:,1) = tmp_R;
    tmp_G = err_img(:,:,2); tmp_G(is_over) = 0; err_img(:,:,2) = tmp_G;
    tmp_B = err_img(:,:,3); tmp_B(is_over) = 0; err_img(:,:,3) = tmp_B;
    imwrite(err_img, fullfile(folder_result, [base_name, '_error_baseline.png']));
end  

%% ================= 4. 全局平均误差计算与保存 =================
mean_bad3_noc = total_bad_noc / total_valid_noc * 100;
mean_bad3_all = total_bad_all / total_valid_all * 100;

% 打印总结果并在txt末尾写入
fprintf('\n======================================================\n');
fprintf('Evaluation Completed!\n');
fprintf('Global Average Bad3.0 NOC: %.2f%%\n', mean_bad3_noc);
fprintf('Global Average Bad3.0 ALL: %.2f%%\n', mean_bad3_all);
fprintf('======================================================\n');

fprintf(fid, '----------------------------------------\n');
fprintf(fid, 'Average\t%.4f\t%.4f\n', mean_bad3_noc, mean_bad3_all);
fclose(fid);