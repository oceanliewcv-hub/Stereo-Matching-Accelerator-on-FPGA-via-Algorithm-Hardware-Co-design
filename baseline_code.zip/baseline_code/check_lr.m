function [result_left, result_right] = check_lr(left_L, right_L, threshold)
% check_lr: 执行左右一致性检查 (LRC) 并根据 GT 限制最大视差
% 输入:
%   left_L: 左图视差图
%   right_L: 右图视差图
%   threshold: LRC 阈值 (通常为 1.0)
%   GT: 真值图 (Ground Truth)，用于确定有效视差范围

    [H, W] = size(left_L);

    % 初始化结果
    result_left = left_L;
    result_right = right_L;

    P = threshold;

    %% 2. For Right Image (右图一致性检查)
    for i = 1:H
        for j = 1:W
            % 如果已经被之前的 GT 过滤置 0 了，就跳过
            if result_right(i,j) == 0
                continue;
            end
            
            c = round(result_right(i,j)); % 使用 round 确保索引为整数
            
            if j + c <= W && j + c >= 1
                d = result_left(i, j + c); % 取出对应的左图视差
                
                % 检查一致性
                if abs(result_right(i,j) - d) > P
                    result_right(i,j) = 0;
                end
            else
                result_right(i,j) = 0; % 超出边界
            end 
        end
    end

    %% 3. For Left Image (左图一致性检查)
    for i = 1:H
        for j = 1:W
            % 如果已经被之前的 GT 过滤置 0 了，就跳过
            if result_left(i,j) == 0
                continue;
            end
            
            a = round(result_left(i,j)); % 使用 round 确保索引为整数
            
            if j - a >= 1 && j - a <= W
                b = result_right(i, j - a); % 取出对应的右图视差
                
                % 检查一致性
                if abs(result_left(i,j) - b) > P 
                    result_left(i,j) = 0;
                end
            else
                result_left(i,j) = 0; % 超出边界
            end
        end
    end
    
end