function filled_disp = fillHolesLRC(im, hole_mask)
    [H, W] = size(im);
    filled_disp = im;
    
    for r = 1:H
        for c = 1:W
            if hole_mask(r, c)
                % 向左找有效值
                left_val = 0;
                for k = c-1:-1:1
                    if ~hole_mask(r, k), left_val = im(r, k); break; end
                end
                % 向右找有效值
                right_val = 0;
                for k = c+1:W
                    if ~hole_mask(r, k), right_val = im(r, k); break; end
                end
                
                % 关键逻辑：取两者中的最小值（假设背景视差更小）
                if left_val > 0 && right_val > 0
                    filled_disp(r, c) = min(left_val, right_val);
                else
                    filled_disp(r, c) = max(left_val, right_val); % 边界情况处理
                end
            end
        end
    end
    % 最后接一个中值滤波去除水平条纹感
    % filled_disp = medfilt2(filled_disp, [3 3]);
end