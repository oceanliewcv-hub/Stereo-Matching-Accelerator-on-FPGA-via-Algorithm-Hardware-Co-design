function [rawCostCube, rawCostCube_right] = census_hanming(left, right, window_size, Dmax)
    [H, W] = size(left);
    w = (window_size - 1) / 2; 
    
    % 使用 uint8 极大地节省内存和带宽
    rawCostCube       = 255 * ones(H, W, Dmax + 1, 'uint8'); 
    rawCostCube_right = 255 * ones(H, W, Dmax + 1, 'uint8'); 
    
    % 获取需要进行代价计算的有效区域 (去除 padding 边界)
    i_idx = (1 + w) : (H - w);
    j_idx = (1 + w) : (W - w);
    
    % =========================================================================
    % 步骤 1：向量化计算整张图的 Census 编码 (剔除中心像素)
    % 纯十字形只包含 4 个臂，总共 4*w 个比较位
    % =========================================================================
    num_bits = 4 * w; 
    
    % 预分配 logical 类型的 3D 矩阵
    census_L = false(length(i_idx), length(j_idx), num_bits);
    census_R = false(length(i_idx), length(j_idx), num_bits);
    
    bit_idx = 1;
    % -- 提取垂直方向上的特征位 (跳过中心点 dy=0) --
    for dy = -w : w
        if dy == 0, continue; end
        census_L(:, :, bit_idx) = left(i_idx + dy, j_idx) > left(i_idx, j_idx);
        census_R(:, :, bit_idx) = right(i_idx + dy, j_idx) > right(i_idx, j_idx);
        bit_idx = bit_idx + 1;
    end
    
    % -- 提取水平方向上的特征位 (跳过中心点 dx=0) --
    for dx = -w : w
        if dx == 0, continue; end
        census_L(:, :, bit_idx) = left(i_idx, j_idx + dx) > left(i_idx, j_idx);
        census_R(:, :, bit_idx) = right(i_idx, j_idx + dx) > right(i_idx, j_idx);
        bit_idx = bit_idx + 1;
    end
    
    % =========================================================================
    % 步骤 2：矩阵错位计算 Hamming 距离
    % =========================================================================
    for d = 0 : Dmax 
        valid_j_start = 1 + w + d;
        valid_j_end   = W - w;
        
        if valid_j_start > valid_j_end
            continue; 
        end
        
        % 映射到局部的切片索引
        local_j_start_L = valid_j_start - w;
        local_j_end_L   = valid_j_end - w;
        
        local_j_start_R = local_j_start_L - d;
        local_j_end_R   = local_j_end_L - d;
        
        % 直接切取对应的 3D 矩阵块
        slice_L = census_L(:, local_j_start_L:local_j_end_L, :);
        slice_R = census_R(:, local_j_start_R:local_j_end_R, :);
        
        % 利用逻辑不等符 ~= 替代 xor，沿着位维度求和得到 Hamming 距离
        hamming_dist = sum(slice_L ~= slice_R, 3);
        
        % 矩阵级饱和截断
        hamming_dist(hamming_dist > 10) = 10;
        
        % 赋值回代价卷 (d+1 因为视差 0 对应索引 1)
        rawCostCube(i_idx, valid_j_start:valid_j_end, d + 1) = uint8(hamming_dist);
    end
end